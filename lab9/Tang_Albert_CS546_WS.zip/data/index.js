const funcData = require("./funcs");

module.exports = {
    funcs: funcData
}