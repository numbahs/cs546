module.exports = {
    about: {
        name: "Albert Tang",
        biography: "Hello, my name is Albert Tang. I am a Computer Science major at Stevens Institute \
of Technology. I am currently a Junior in the school and I am very new \
to JavaScript. I have had a fun time learning this language as it has \
some very interesting things that can be done for the syntax.\nI am definitely \
excited to learn more about from this class because the assignments are \
definitely fun to work on.",
        favoriteShows: ["Doctor Who", "Game of Thrones", "Rick and Morty"],
        hobbies: ["Playing video games", "Programming", "Browsing the web"]
    },
    story: {
        storyTitle: "The Story of a Time I had 1 Hour Left to do a Homework Assignment",
        story: "During that frightful night, there was a long walk home still to my apartment. The \
homework assignment in the back of my head, I continued to worry about \
how much time it would take to finish my assignment. But before all of \
this, I decided to have a fun time and play board games with my friends. \
The decision was not a very good idea, but I had felt like I could finish \
the assignment in time. These board games were very fun but they consumed \
a very large amount of time. These went on for hours and then hunger \
struck. We all started to get very hungry and decided that we would go \
out to eat Midtown Philly Cheesesteaks. Time continued to pass as we \
ate a juicy cheesesteak. I decided the time was becoming too late, however, \
and headed out early. Now, I am on the walk to my apartment where it \
is a bit chilly out, probably foretelling me not finishing the assignment. \
But I sped up and speed walked all the way into my apartment. As soon \
as I sat down, I started typing about the scare I went into to get that \
assignment finished. It is 11:38 and I finally finish the assignment."
    },
    education: [
        {
            schoolName: "Elmwood Park Memorial Senior High",
            degree: "High School degree",
            favoriteClass: "Calculus AB",
            favoriteMemory: "I remember most of the time that I was in band. It was a lot of fun \
being with my friends and learning an instrument from very little \
experience to having a good grasp on the instrument. I am, however, \
definitely not a professional at the clarinet though."
        },
        {
            schoolName: "Elmwood Park Memorial Junior High",
            degree: "Middle School Graduation",
            favoriteClass: "Math",
            favoriteMemory: "I've Always had a fun time doing math because I could \
understand it very well. I also was playing my clarinet during Middle \
School too."
        }
    ]
}