const recipeData = require('./recipes');
const commentsData = require('./comments');

module.exports = {
    recipes : recipeData,
    comments : commentsData
}